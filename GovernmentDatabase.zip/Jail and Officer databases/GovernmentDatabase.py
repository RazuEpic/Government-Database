class Jail_Database:
    def __init__(self, name: str, job: str, age: int, race: str, crime: str, months: int, jail_facility: str, is_incarcerated: bool = None, sex_off_registry: bool = None, on_probation: bool = None):
        self.name = name
        self.job = job
        self.age = age
        self.race = race
        self.crime = crime
        self.months = months
        self.jail_facility = jail_facility
        self.is_incarcerated = is_incarcerated
        self.sex_off_registry = sex_off_registry
        self.on_probation = on_probation

    def __str__(self):
        return (f"""
Name: {self.name}; Age: {self.age}; Race: {self.race}
Previous Job: {self.job}
Crime: {self.crime}; Months: {self.months}
Currently incarcerated?: {self.is_incarcerated}; Currently on probation?: {self.on_probation}
Currently on the sex offenders registry?: {self.sex_off_registry}
""")

class Officer_Database:
    def __init__(self, name, race, position, titles, badge_num, age, department, years_on, arrest_nums, firearm_name, confirmed_kills, on_force = None, is_fired = None):
        self.name = name
        self.race = race
        self.position = position
        self.titles = titles
        self.badge_num = badge_num
        self.age = age
        self.department = department
        self.years_on = years_on
        self.arrest_nums = arrest_nums
        self.firearm_name = firearm_name
        self.confirmed_kills = confirmed_kills
        self.on_force = on_force
        self.is_fired = is_fired

    def __str__(self):
        return (f"""
Title: {self.titles}; Name: {self.name}; Badge Number: {self.badge_num}; Race: {self.race}
Department: {self.department}; Position: {self.position}
Age: {self.age}; Years on the force: {self.years_on}
Firearm: {self.firearm_name}; Confirmed kills: {self.confirmed_kills}
Still on the force?: {self.on_force}; Have they been fired?: {self.is_fired}
""")

# New standalone function to read from file and create instance
def from_file(filename, cls):
    with open(filename, "r") as file:
        lines = file.readlines()
    return cls(*[line.strip() for line in lines])

# Loading data from files
database_list = [
    from_file("Tobias.txt", Jail_Database),
    from_file("Richard.txt", Jail_Database),
    from_file("Scott.txt", Jail_Database),  # Changed from Neiko.txt to Scott.txt
    from_file("Negan.txt", Jail_Database),
    from_file("Officer_Negan.txt", Officer_Database),
    from_file("Officer_Erik.txt", Officer_Database),
]

choice = int(input("""
1) Richard, Status: (Misdemeanant.)
2) Tobias, Status: (Misdemeanant.)
3) Scott, Status: (Felon.)
4) Negan, Status: (Felon.)
5) Officer Negan, Status: (No longer employed.)
6) Officer Erik, Status: (Continued employment.)

>> """))

if 1 <= choice <= len(database_list):
    print(database_list[choice - 1])
else:
    print("Invalid choice.")
